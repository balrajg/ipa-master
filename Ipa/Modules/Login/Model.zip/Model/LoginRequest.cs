﻿using System;
using Newtonsoft.Json;

namespace Mentor
{
	public class LoginRequest
	{
		//{"deviceToken":"DEV3342V4", "userName":"", "password":""}
		[JsonProperty ( PropertyName = "deviceToken", NullValueHandling = NullValueHandling.Ignore)]
		public string DeviceToken { get; set;}
		[JsonProperty ( PropertyName = "userName", NullValueHandling = NullValueHandling.Ignore)]
		public string UserName { get; set;}
		[JsonProperty ( PropertyName = "password", NullValueHandling = NullValueHandling.Ignore)]
		public string Password { get; set;}
	}
}

